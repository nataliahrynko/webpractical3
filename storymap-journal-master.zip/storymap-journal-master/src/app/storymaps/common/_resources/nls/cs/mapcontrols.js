define({
  "commonMapControls": {
    "common": {
      "settings": "Nastavení",
      "openDefault": "Otevřít jako výchozí"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Podkladová mapa",
      "expandFactorLabel": "Faktor rozšíření",
      "expandFactorPopover": "Poměr mezi velikostí mapy přehledu a obdélníkem rozsahu zobrazeným na mapě přehledu. Výchozí hodnota je 2, což znamená, že mapa přehledu bude minimálně dvakrát tak velká jako obdélník rozsahu."
    }
  }
});