define({
  "commonMapControls": {
    "common": {
      "settings": "Postavke",
      "openDefault": "Otvori kao podrazumevano"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Pozadinska mapa",
      "expandFactorLabel": "Faktor proširivanja",
      "expandFactorPopover": "Odnos između veličine pregledne mape i obuhvata prikazanog pravougaonika na preglednoj mapi. Podrazumevana vrednost je 2, što znači da će pregledna mapa da bude bar dva puta veća od opsega pravougaonika."
    }
  }
});