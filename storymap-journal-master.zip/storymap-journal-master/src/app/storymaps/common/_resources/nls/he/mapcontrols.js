define({
  "commonMapControls": {
    "common": {
      "settings": "הגדרות",
      "openDefault": "פתוח כברירת מחדל"
    },
    "overview": {
      "basemapGalleryBtnLabel": "מפת בסיס",
      "expandFactorLabel": "פקטור הרחבה",
      "expandFactorPopover": "היחס בין גודל מפת ההתמצאות ותיחום המלבן המוצג במפת ההתמצאות. ערך ברירת המחדל הוא 2, משמעותו שמפת ההתמצאות תהיה לפחות פי שנים מגודל התיחום של המלבן."
    }
  }
});