define({
  "commonMapControls": {
    "common": {
      "settings": "Paramètres",
      "openDefault": "Ouvert par défaut"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Fond de carte",
      "expandFactorLabel": "Facteur de développement",
      "expandFactorPopover": "Ratio entre la taille de la vue générale et le rectangle d'emprise affiché sur la vue générale. La valeur par défaut est de 2, ce qui signifie que la vue générale est au moins deux fois plus grande que le rectangle d''emprise."
    }
  }
});