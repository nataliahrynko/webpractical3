define({
  "commonMapControls": {
    "common": {
      "settings": "Ayarlar",
      "openDefault": "Varsayılan olarak aç"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Altlık Harita",
      "expandFactorLabel": "Genişletme Çarpanı",
      "expandFactorPopover": "Genel bakış haritası ile onun üstünde görüntülenen yayılım dikdörtgeni boyutu arasındaki orandır. Varsayılan değeri 2'dir ve genel bakış haritasının yayılım dikdörtgeninin en az iki katı büyüklüğünde olacağı anlamına gelir."
    }
  }
});