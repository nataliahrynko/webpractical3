define({
  "commonMapControls": {
    "common": {
      "settings": "設定",
      "openDefault": "預設打開"
    },
    "overview": {
      "basemapGalleryBtnLabel": "底圖",
      "expandFactorLabel": "擴展因子",
      "expandFactorPopover": "鷹眼圖大小和鷹眼圖上顯示的範圍矩形大小之比。預設值為 2，表示鷹眼圖至少為範圍矩形大小的兩倍。"
    }
  }
});