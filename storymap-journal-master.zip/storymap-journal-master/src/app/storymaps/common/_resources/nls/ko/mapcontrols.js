define({
  "commonMapControls": {
    "common": {
      "settings": "설정",
      "openDefault": "기본적으로 열기"
    },
    "overview": {
      "basemapGalleryBtnLabel": "베이스맵",
      "expandFactorLabel": "확장 계수",
      "expandFactorPopover": "오버뷰 맵과 맵에 표시되는 범위 사각형 간의 크기 비율입니다. 기본값은 '2'로 오버뷰 맵이 범위 사각형보다 최소 2배 더 크다는 의미입니다."
    }
  }
});