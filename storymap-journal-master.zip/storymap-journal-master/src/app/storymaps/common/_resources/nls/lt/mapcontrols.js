define({
  "commonMapControls": {
    "common": {
      "settings": "Nuostatos",
      "openDefault": "Atidaryti kaip numatyta"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Pagrindo žemėlapis",
      "expandFactorLabel": "Didinimo koeficientas",
      "expandFactorPopover": "Apžvalgos žemėlapio ir jame rodomo aprėpties stačiakampio santykis. Numatytoji reikšmė yra 2, t. y. apžvalgos žemėlapis bus bent dukart didesnis už aprėpties stačiakampį."
    }
  }
});