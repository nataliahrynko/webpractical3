# Code of conduct

**TL;DR**<br>
We expect folks that participate in both our online and [IRL](https://www.urbandictionary.com/define.php?term=IRL) communities to be kind and considerate of others at all times.

Esri's official CoC text can be found at http://www.esri.com/events/code-of-conduct
